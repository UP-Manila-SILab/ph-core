# task-single-example - Draft PH Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **task-single-example**

## Example Task: task-single-example

A laboratory task has been requested for Juan Dela Cruz by Dr. Maria Clara Santos. The task involves collecting a blood sample for routine CBC testing. The task status is requested with routine priority, scheduled for execution between 09:00 and 10:00 on March 15, 2024. The Department of Health - Central Office is the assigned owner for this task. Additional note: Patient has confirmed appointment. Please ensure fasting status is verified before sample collection.



## Resource Content

```json
{
  "resourceType" : "Task",
  "id" : "task-single-example",
  "meta" : {
    "profile" : ["http://doh.gov.ph/fhir/ph-core/StructureDefinition/ph-core-task"]
  },
  "status" : "requested",
  "intent" : "order",
  "priority" : "routine",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "82078001",
      "display" : "Collection of blood specimen for laboratory"
    }],
    "text" : "Blood sample collection"
  },
  "description" : "Collect blood sample for complete blood count (CBC) testing",
  "for" : {
    "reference" : "Patient/patient-single-example"
  },
  "encounter" : {
    "reference" : "Encounter/encounter-single-example"
  },
  "executionPeriod" : {
    "start" : "2024-03-15T09:00:00+08:00",
    "end" : "2024-03-15T10:00:00+08:00"
  },
  "authoredOn" : "2024-03-15T08:30:00+08:00",
  "lastModified" : "2024-03-15T08:30:00+08:00",
  "requester" : {
    "reference" : "Practitioner/practitioner-single-example"
  },
  "owner" : {
    "reference" : "Organization/organization-single-example"
  },
  "note" : [{
    "authorReference" : {
      "reference" : "Practitioner/practitioner-single-example"
    },
    "time" : "2024-03-15T08:30:00+08:00",
    "text" : "Patient has confirmed appointment. Please ensure fasting status is verified before sample collection."
  }]
}

```
