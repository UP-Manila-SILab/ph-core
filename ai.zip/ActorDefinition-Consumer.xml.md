# PH Core Consumer - XML Representation - Draft PH Core Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PH Core Consumer**

## : PH Core Consumer - XML Representation

| |
| :--- |
| Draft as of 2026-04-22 |

[Raw xml](ActorDefinition-Consumer.xml) | [Download](ActorDefinition-Consumer.xml)

